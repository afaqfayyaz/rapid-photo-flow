import React from 'react';
import { AppRouter } from './app-routing';

function App() {
  return <AppRouter />;
}

export default App;

